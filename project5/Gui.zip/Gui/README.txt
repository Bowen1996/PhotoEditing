Name: Bowen Gui
Email: bgui7@gatech.edu
Version: Java 8

Specific Info:
1. I have a seperate mode for the magnet. The mode will copy over all the thumbnails into that layout;
however, I set it so all the thumbnails are originally placed at (0,0)
2. the thumbnails do react to the magnets; however, they only behave normally when the magnets are 
placed in the lower right or upper left; I'm not sure what is causing this bug, but lower-left and 
upper-right are causing the thumbnails some bugs.
3. the magnets may react a little differently when clicked and drag, that's because I set it so 
the magnet's top-left hand corner will follow exactly where the mouse is, thus the magnet will adjust
itself so that the top-left hand corner alligns with the mouse pointer.
